﻿using System;
using System.Collections.Generic;
using System.Text;
using WpfAppTCS_2341269.Model;

namespace WpfAppTCS_2341269.IRepository
{
    public interface IEmployeeRepository :IRepository<Employee>
    {
    }
}
