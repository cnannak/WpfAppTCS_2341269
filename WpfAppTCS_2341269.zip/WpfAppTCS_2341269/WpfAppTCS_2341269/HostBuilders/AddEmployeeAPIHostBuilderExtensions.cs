﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Text;
using WpfAppTCS_2341269.Model;

namespace WpfAppTCS_2341269.HostBuilders
{
    public static class AddEmployeeAPIHostBuilderExtensions
    {
        public static IHostBuilder AddEmployeeAPI(this IHostBuilder host)
        {
            //host.ConfigureServices((context, services) =>
            //{
            //    string apiKey = context.Configuration.GetValue<string>("fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
            //    services.AddSingleton(new EmployeeModelingPrepAPIKey(apiKey));

            //    services.AddHttpClient<EmployeeModelingPrepHttpClient>(c =>
            //    {
            //        c.BaseAddress = new Uri("https://gorest.co.in/public-api/users/");
            //    });
            //});

            return host;
        }
    }
}
