﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using WpfAppTCS_2341269.IRepository;
using WpfAppTCS_2341269.Model;

namespace WpfAppTCS_2341269.Repository
{
    public class EmployeeRepository : Repository<Employee>, IEmployeeRepository
    {
        private readonly IHttpClientFactory _clientFactory;

        public EmployeeRepository(IHttpClientFactory clientFactory) : base(clientFactory)
        {
            _clientFactory = clientFactory;
        }
    }
}
